<?php
define('SITE_ROOT', ''); // If installed on a sub-folder, replace the empty constant with the folder's name
define('PAGINATION', 10); // Pagination results per page