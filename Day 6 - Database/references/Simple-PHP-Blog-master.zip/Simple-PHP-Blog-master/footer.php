<p>
<div class="w3-container w3-teal">
    <p>All rights reserved | <?php echo date("Y"); ?></p>
</div>
</p>
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.19.1/trumbowyg.min.js"></script>
<script>
    $('#description').trumbowyg();
</script>

</body>