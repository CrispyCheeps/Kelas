let A;
const B = [];

console.log(A);
console.log(B);

let fruits = ["semangka", "melon", "mangga", "mengkudu", "bengkoang"];
fruits.push("nanas");
console.log(fruits);

fruits.splice(1, 1, "pepaya");
console.log(fruits);

fruits.pop();
console.log(fruits);