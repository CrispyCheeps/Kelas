let i=1
while (i<=120) {
    console.log("Halo, saya orang ke " + i);
    i++
}