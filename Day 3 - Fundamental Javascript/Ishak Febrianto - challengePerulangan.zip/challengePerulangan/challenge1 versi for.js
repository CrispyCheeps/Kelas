for(let i = 1; i<=120;i++) {
    console.log("Halo, saya orang ke " + i);
}